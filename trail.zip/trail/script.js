// Countdown starts here
document.getElementById("dateSelector").addEventListener("change", function(){
    var input= this.value;
    var home = new Date(input);
    
    window.localStorage.setItem("home",input);

var home = window.localStorage.getItem("home");
home = new Date(input);

// GET TODAY'S DATE
let today = new Date();
// CONVERT TO NUMERICAL REPRESENTATION (getTime())
let homeTime = home.getTime();
console.log(homeTime);
let currentTime = today.getTime();
console.log(currentTime);
// SCALE DOWN TO DAYS
let msLeft = homeTime - currentTime;
console.log(msLeft);
let secondsLeft = msLeft / 1000;
let minutesLeft = secondsLeft / 60;
let hoursLeft = minutesLeft / 60;
let daysLeft = hoursLeft / 24;

let element = document.getElementById("replaceMe");
element.innerHTML = Math.ceil(daysLeft)});

///change placeholder color

